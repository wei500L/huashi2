package com.huashi.eftransfer.app.modules.user.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.huashi.eftransfer.app.common.persistence.BaseAuditEntity;

import java.time.LocalDateTime;

@TableName("student_profile")
public class StudentProfileEntity extends BaseAuditEntity {

    @TableField("user_id")
    private Long userId;

    @TableField("student_no")
    private String studentNo;

    @TableField("grade_name")
    private String gradeName;

    @TableField("english_level")
    private String englishLevel;

    @TableField("french_level")
    private String frenchLevel;

    @TableField("course_stage")
    private String courseStage;

    @TableField("composite_score")
    private Integer compositeScore;

    @TableField("daily_training_target")
    private Integer dailyTrainingTarget;

    @TableField("weekly_accuracy_target")
    private Integer weeklyAccuracyTarget;

    @TableField("learning_goals_updated_at")
    private LocalDateTime learningGoalsUpdatedAt;

    @TableField("learning_profile_snapshot_json")
    private String learningProfileSnapshotJson;

    @TableField("learning_profile_updated_at")
    private LocalDateTime learningProfileUpdatedAt;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getStudentNo() {
        return studentNo;
    }

    public void setStudentNo(String studentNo) {
        this.studentNo = studentNo;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    public String getEnglishLevel() {
        return englishLevel;
    }

    public void setEnglishLevel(String englishLevel) {
        this.englishLevel = englishLevel;
    }

    public String getFrenchLevel() {
        return frenchLevel;
    }

    public void setFrenchLevel(String frenchLevel) {
        this.frenchLevel = frenchLevel;
    }

    public String getCourseStage() {
        return courseStage;
    }

    public void setCourseStage(String courseStage) {
        this.courseStage = courseStage;
    }

    public Integer getCompositeScore() {
        return compositeScore;
    }

    public void setCompositeScore(Integer compositeScore) {
        this.compositeScore = compositeScore;
    }

    public Integer getDailyTrainingTarget() {
        return dailyTrainingTarget;
    }

    public void setDailyTrainingTarget(Integer dailyTrainingTarget) {
        this.dailyTrainingTarget = dailyTrainingTarget;
    }

    public Integer getWeeklyAccuracyTarget() {
        return weeklyAccuracyTarget;
    }

    public void setWeeklyAccuracyTarget(Integer weeklyAccuracyTarget) {
        this.weeklyAccuracyTarget = weeklyAccuracyTarget;
    }

    public LocalDateTime getLearningGoalsUpdatedAt() {
        return learningGoalsUpdatedAt;
    }

    public void setLearningGoalsUpdatedAt(LocalDateTime learningGoalsUpdatedAt) {
        this.learningGoalsUpdatedAt = learningGoalsUpdatedAt;
    }

    public String getLearningProfileSnapshotJson() {
        return learningProfileSnapshotJson;
    }

    public void setLearningProfileSnapshotJson(String learningProfileSnapshotJson) {
        this.learningProfileSnapshotJson = learningProfileSnapshotJson;
    }

    public LocalDateTime getLearningProfileUpdatedAt() {
        return learningProfileUpdatedAt;
    }

    public void setLearningProfileUpdatedAt(LocalDateTime learningProfileUpdatedAt) {
        this.learningProfileUpdatedAt = learningProfileUpdatedAt;
    }
}
